
import ee
ee.Initialize()

def export_gee_fire_data(start_date, end_date, region_geojson):
    fires = ee.ImageCollection("FIRMS").filterDate(start_date, end_date)
    region = ee.Geometry.Polygon(region_geojson)
    image = fires.select("T21").mean().clip(region)
    url = image.getDownloadURL({
        'name': 'gee_fire_heatmap',
        'scale': 1000,
        'region': region_geojson
    })
    print("Download GEE Image: ", url)

# Example
# region = [[[103.8, 1.2], [104.1, 1.2], [104.1, 1.4], [103.8, 1.4], [103.8, 1.2]]]
# export_gee_fire_data("2024-04-01", "2024-04-30", region)
