#!/usr/bin/env python3
"""
Advanced Spatiotemporal Data Fusion Example
==========================================

This example demonstrates advanced techniques for fusing MODIS and VIIRS fire data,
including confidence weighting, multi-temporal analysis, and quality assessment.

Addresses the manuscript's requirements for detailed preprocessing methodologies.
"""

import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fire_data_toolkit import FireDataProcessor
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
from scipy.spatial.distance import cdist
from sklearn.cluster import DBSCAN
import warnings

warnings.filterwarnings('ignore')


class AdvancedFireFusion:
    """
    Advanced spatiotemporal fusion techniques for satellite fire data.

    This class implements sophisticated methods for combining MODIS (1km) and 
    VIIRS (375m) fire products with quality assessment and validation.
    """

    def __init__(self):
        self.fusion_stats = {}

    def adaptive_fusion(self, modis_df, viirs_df,
                        base_spatial_threshold=0.5,
                        base_temporal_threshold=12,
                        confidence_weight=0.3):
        """
        Adaptive fusion with dynamic thresholds based on data density.

        Args:
            modis_df: MODIS fire data
            viirs_df: VIIRS fire data
            base_spatial_threshold: Base spatial threshold in km
            base_temporal_threshold: Base temporal threshold in hours
            confidence_weight: Weight for confidence in threshold adjustment
        """
        print("🔄 Performing adaptive spatiotemporal fusion...")

        if modis_df.empty or viirs_df.empty:
            return pd.concat([modis_df, viirs_df], ignore_index=True)

        # Calculate data density for adaptive thresholds
        viirs_density = len(viirs_df) / self._calculate_area(viirs_df)
        modis_density = len(modis_df) / self._calculate_area(modis_df)

        # Adjust thresholds based on data density
        density_factor = max(0.5, min(2.0, viirs_density / (modis_density + 1e-6)))

        adaptive_spatial = base_spatial_threshold * density_factor
        adaptive_temporal = base_temporal_threshold * (2 - density_factor)

        print(f"   📊 Adaptive spatial threshold: {adaptive_spatial:.2f} km")
        print(f"   📊 Adaptive temporal threshold: {adaptive_temporal:.1f} hours")

        # Standardize data
        modis_std = self._standardize_fire_data(modis_df, 'MODIS')
        viirs_std = self._standardize_fire_data(viirs_df, 'VIIRS')

        # Perform fusion with quality metrics
        fused_data = self._quality_weighted_fusion(
            modis_std, viirs_std,
            adaptive_spatial, adaptive_temporal,
            confidence_weight
        )

        # Calculate fusion statistics
        self._calculate_fusion_stats(modis_std, viirs_std, fused_data)

        return fused_data

    def multi_temporal_fusion(self, fire_data_list, time_windows=[6, 12, 24]):
        """
        Multi-temporal fusion using different time windows.

        Args:
            fire_data_list: List of (modis_df, viirs_df, date) tuples
            time_windows: List of time windows in hours for fusion
        """
        print("🕐 Performing multi-temporal fusion...")

        all_fused = []

        for time_