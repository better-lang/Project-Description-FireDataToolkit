#!/usr/bin/env python3
"""
FireDataToolkit Basic Usage Example
==================================

This example demonstrates the basic workflow for processing urban fire data
using the FireDataToolkit. It covers data download, fusion, feature extraction,
and export for decision-making models.

Author: FireDataToolkit Team
Date: 2024
"""

import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fire_data_toolkit import FireDataProcessor, GEEFireVisualizer
import pandas as pd
from datetime import datetime, timedelta


def main():
    """Main example workflow"""

    print("🔥 FireDataToolkit - Basic Usage Example")
    print("=" * 50)

    # 1. Initialize the processor
    processor = FireDataProcessor(data_dir="./example_data")

    # 2. Set your NASA FIRMS API key (REQUIRED)
    # Register at: https://firms.modaps.eosdis.nasa.gov/api/
    processor.map_key = "YOUR_NASA_FIRMS_MAP_KEY"  # Replace with your actual key

    if processor.map_key == "YOUR_NASA_FIRMS_MAP_KEY":
        print("⚠️  Please set your NASA FIRMS API key!")
        print("   1. Register at: https://firms.modaps.eosdis.nasa.gov/api/")
        print("   2. Replace 'YOUR_NASA_FIRMS_MAP_KEY' with your actual key")
        print("   3. Run this example again")
        return

    # 3. Define study parameters
    # Example: Fire-prone regions in California
    california_bbox = (-124.0, 32.0, -114.0, 42.0)  # (min_lon, min_lat, max_lon, max_lat)

    # Date range - last 30 days
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)

    start_str = start_date.strftime('%Y-%m-%d')
    end_str = end_date.strftime('%Y-%m-%d')

    print(f"📅 Processing period: {start_str} to {end_str}")
    print(f"🗺️  Study area: California ({california_bbox})")

    # 4. Download fire data from multiple sources
    print("\n🛰️  Downloading satellite fire data...")

    # MODIS Collection 6 (1km resolution)
    modis_data = processor.download_firms_data(
        bbox=california_bbox,
        start_date=start_str,
        end_date=end_str,
        source='MODIS_C6'
    )

    # VIIRS SNPP (375m resolution)
    viirs_data = processor.download_firms_data(
        bbox=california_bbox,
        start_date=start_str,
        end_date=end_str,
        source='VIIRS_SNPP'
    )

    print(f"   📊 MODIS fires: {len(modis_data)}")
    print(f"   📊 VIIRS fires: {len(viirs_data)}")

    # 5. Perform spatiotemporal data fusion
    print("\n🔄 Performing spatiotemporal data fusion...")
    fused_data = processor.spatiotemporal_fusion(
        modis_df=modis_data,
        viirs_df=viirs_data,
        spatial_threshold=0.5,  # 0.5 km spatial matching
        temporal_threshold=12  # 12 hour temporal matching
    )

    print(f"   📊 Fused dataset: {len(fused_data)} fire points")

    # 6. Generate city boundaries for California cities
    print("\n🌐 Generating city boundaries...")
    california_cities = [
        'Los Angeles', 'San Francisco', 'San Diego', 'Sacramento',
        'Fresno', 'Oakland', 'Bakersfield', 'Anaheim', 'Riverside',
        'Stockton', 'Chula Vista', 'Fremont', 'San Bernardino'
    ]

    city_boundaries = processor.generate_city_geojson(california_cities, 'USA')
    print(f"   📍 Generated boundaries for {len(city_boundaries)} cities")

    # 7. Aggregate fire data to city level
    print("\n📊 Aggregating fire data to city level...")
    city_fire_data = processor.aggregate_to_cities(fused_data, city_boundaries)

    # 8. Display sample results
    print("\n📈 Sample fire risk analysis:")
    print("-" * 40)

    if not city_fire_data.empty:
        # Sort by fire risk
        city_fire_data = city_fire_data.sort_values('initial_opinion_risk', ascending=False)

        for _, city in city_fire_data.head(5).iterrows():
            print(f"🏙️  {city['city_name']:<15} | "
                  f"Fires: {city['total_fire_count']:>3} | "
                  f"Risk: {city['initial_opinion_risk']:.3f} | "
                  f"FRP: {city['mean_frp']:>6.1f} MW")

    # 9. Extract detailed features for one city
    if not city_fire_data.empty:
        top_risk_city = city_fire_data.iloc[0]
        print(f"\n🔍 Detailed analysis for {top_risk_city['city_name']}:")
        print("-" * 40)

        features_to_show = [
            ('total_fire_count', 'Total Fires'),
            ('fire_density', 'Fire Density (fires/km²)'),
            ('mean_frp', 'Mean FRP (MW)'),
            ('max_frp', 'Max FRP (MW)'),
            ('daily_fire_rate', 'Daily Fire Rate'),
            ('high_confidence_ratio', 'High Confidence Ratio'),
            ('initial_opinion_risk', 'Risk Score'),
            ('initial_opinion_urgency', 'Urgency Score'),
            ('initial_opinion_resources', 'Resource Need Score')
        ]

        for feature, label in features_to_show:
            value = top_risk_city[feature]
            if isinstance(value, float):
                print(f"   {label:<25}: {value:.3f}")
            else:
                print(f"   {label:<25}: {value}")

    # 10. Export data in multiple formats
    print("\n💾 Exporting processed data...")

    # Excel format (recommended for decision modeling)
    excel_file = processor.export_modeling_data(
        city_fire_data,
        format='excel',
        filename='california_fire_analysis'
    )

    # CSV format (for further analysis)
    csv_file = processor.export_modeling_data(
        city_fire_data,
        format='csv',
        filename='california_fire_data'
    )

    # JSON format (for web applications)
    json_file = processor.export_modeling_data(
        city_fire_data,
        format='json',
        filename='california_fire_json'
    )

    print(f"   📄 Excel: {excel_file}")
    print(f"   📄 CSV: {csv_file}")
    print(f"   📄 JSON: {json_file}")

    # 11. Generate Google Earth Engine visualization (optional)
    print("\n🗺️  Generating fire heatmap...")
    visualizer = GEEFireVisualizer()

    if visualizer.initialized:
        heatmap_url = visualizer.create_fire_heatmap(
            bbox=california_bbox,
            start_date=start_str,
            end_date=end_str
        )
        if heatmap_url:
            print(f"   🌐 Heatmap URL: {heatmap_url}")
    else:
        print("   ⚠️  Google Earth Engine not available")
        print("   Install with: pip install earthengine-api")
        print("   Then authenticate: earthengine authenticate")

    # 12. Summary statistics
    print("\n📈 Processing Summary:")
    print("=" * 30)
    print(f"Cities processed: {len(city_fire_data)}")
    print(f"Total fire points: {len(fused_data)}")
    print(f"Date range: {start_str} to {end_str}")
    print(f"Study area: California")

    if not city_fire_data.empty:
        total_fires = city_fire_data['total_fire_count'].sum()
        avg_risk = city_fire_data['initial_opinion_risk'].mean()
        max_risk = city_fire_data['initial_opinion_risk'].max()

        print(f"Total fires detected: {total_fires}")
        print(f"Average risk score: {avg_risk:.3f}")
        print(f"Maximum risk score: {max_risk:.3f}")

        high_risk_cities = (city_fire_data['initial_opinion_risk'] > 0.5).sum()
        print(f"High-risk cities: {high_risk_cities}")

    print("\n✅ Processing complete!")
    print(f"📁 All files saved in: {processor.data_dir}")

    return processor, city_fire_data


def analyze_temporal_patterns(fire_data):
    """Analyze temporal patterns in fire data"""

    if fire_data.empty:
        return

    print("\n📅 Temporal Pattern Analysis:")
    print("-" * 30)

    # Convert date columns
    fire_data['date'] = pd.to_datetime(fire_data['acq_date'])
    fire_data['hour'] = pd.to_datetime(fire_data['acq_time'], format='%H%M').dt.hour
    fire_data['weekday'] = fire_data['date'].dt.day_name()

    # Daily patterns
    daily_counts = fire_data.groupby('date').size()
    print(f"Busiest fire day: {daily_counts.idxmax()} ({daily_counts.max()} fires)")

    # Hourly patterns
    hourly_counts = fire_data.groupby('hour').size()
    peak_hour = hourly_counts.idxmax()
    print(f"Peak fire hour: {peak_hour:02d}:00 ({hourly_counts.max()} fires)")

    # Weekly patterns
    weekly_counts = fire_data.groupby('weekday').size()
    print(f"Busiest weekday: {weekly_counts.idxmax()} ({weekly_counts.max()} fires)")


def analyze_spatial_clusters(fire_data):
    """Analyze spatial clustering of fires"""

    if fire_data.empty:
        return

    print("\n🗺️  Spatial Cluster Analysis:")
    print("-" * 30)

    # Calculate basic spatial statistics
    lat_range = fire_data['latitude'].max() - fire_data['latitude'].min()
    lon_range = fire_data['longitude'].max() - fire_data['longitude'].min()

    print(f"Latitude span: {lat_range:.3f}°")
    print(f"Longitude span: {lon_range:.3f}°")

    # Fire density hotspots
    fire_data['lat_bin'] = pd.cut(fire_data['latitude'], bins=10)
    fire_data['lon_bin'] = pd.cut(fire_data['longitude'], bins=10)

    spatial_counts = fire_data.groupby(['lat_bin', 'lon_bin']).size()
    max_density_bins = spatial_counts.idxmax()

    print(f"Highest density region: {max_density_bins}")
    print(f"Fires in hotspot: {spatial_counts.max()}")


if __name__ == "__main__":
    # Run the main example
    processor, city_data = main()

    # Additional analysis examples
    if not city_data.empty:
        # Download raw fire data for temporal analysis
        california_bbox = (-124.0, 32.0, -114.0, 42.0)
        end_date = datetime.now()
        start_date = end_date - timedelta(days=30)

        # Get sample fire data for analysis
        if processor.map_key != "YOUR_NASA_FIRMS_MAP_KEY":
            sample_data = processor.download_firms_data(
                california_bbox,
                start_date.strftime('%Y-%m-%d'),
                end_date.strftime('%Y-%m-%d'),
                'VIIRS_SNPP'
            )

            if not sample_data.empty:
                analyze_temporal_patterns(sample_data)
                analyze_spatial_clusters(sample_data)