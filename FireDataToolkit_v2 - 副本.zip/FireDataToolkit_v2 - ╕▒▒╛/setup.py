#!/usr/bin/env python3
"""
Setup script for FireDataToolkit
"""

from setuptools import setup, find_packages
import os

# Read the README file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read requirements
with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="fire-data-toolkit",
    version="1.0.0",
    author="FireDataToolkit Research Team",
    author_email="contact@firedatatoolkit.org",
    description="A reproducible Python toolkit for urban fire remote sensing data processing",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/username/FireDataToolkit",
    project_urls={
        "Bug Reports": "https://github.com/username/FireDataToolkit/issues",
        "Source": "https://github.com/username/FireDataToolkit",
        "Documentation": "https://firedatatoolkit.readthedocs.io/",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: GIS",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "Topic :: Scientific/Engineering :: Atmospheric Science",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "black>=22.0.0",
            "flake8>=5.0.0",
            "pre-commit>=2.20.0",
            "sphinx>=4.0.0",
            "sphinx-rtd-theme>=1.0.0",
        ],
        "viz": [
            "matplotlib>=3.5.0",
            "seaborn>=0.11.0",
            "folium>=0.14.0",
            "plotly>=5.0.0",
        ],
        "ml": [
            "scikit-learn>=1.1.0",
            "tensorflow>=2.8.0",
            "torch>=1.12.0",
        ]
    },
    entry_points={
        "console_scripts": [
            "fire-data-toolkit=fire_data_toolkit:main",
        ],
    },
    include_package_data=True,
    package_data={
        "fire_data_toolkit": [
            "templates/*.json",
            "templates/*.yaml",
            "examples/*.py",
            "examples/*.ipynb",
        ],
    },
    keywords=[
        "fire detection", "remote sensing", "satellite data", "MODIS", "VIIRS",
        "urban planning", "disaster management", "decision making", "GIS",
        "spatiotemporal analysis", "data fusion", "digital twin"
    ],
)