"""
FireDataToolkit: A reproducible Python toolkit for urban fire remote sensing data processing
=======================================================================================

This toolkit provides comprehensive preprocessing of spatiotemporal satellite data for urban fire
management and consensus decision-making frameworks like HOD-CC-CRP.

Author: Research Team
License: MIT
Version: 1.0.0
"""

import os
import requests
import pandas as pd
import numpy as np
import geopandas as gpd
from datetime import datetime, timedelta
import json
from typing import Dict, List, Tuple, Optional, Union
import warnings

warnings.filterwarnings('ignore')

# Google Earth Engine imports (optional - requires authentication)
try:
    import ee

    EE_AVAILABLE = True
except ImportError:
    EE_AVAILABLE = False
    print("Google Earth Engine not available. Install with: pip install earthengine-api")


class FireDataProcessor:
    """
    Main class for processing fire remote sensing data from multiple satellite sources.

    Supports:
    - MODIS Collection 6 Fire and Thermal Anomalies (MOD14A1/MYD14A1) - 1km resolution
    - VIIRS 375m Active Fire product (VNP14IMGML) - 375m resolution
    - Sentinel-2 and Landsat integration via Google Earth Engine
    """

    def __init__(self, data_dir: str = "./fire_data"):
        """
        Initialize the FireDataProcessor.

        Args:
            data_dir: Directory to store downloaded and processed data
        """
        self.data_dir = data_dir
        self.ensure_directories()

        # NASA FIRMS API configuration
        self.firms_base_url = "https://firms.modaps.eosdis.nasa.gov/api/area/csv"
        self.map_key = "YOUR_NASA_FIRMS_MAP_KEY"  # Users need to register at https://firms.modaps.eosdis.nasa.gov/api/

        # Satellite data specifications
        self.satellite_specs = {
            'MODIS': {
                'resolution': 1000,  # meters
                'temporal_resolution': 'daily',
                'bands': ['fire_mask', 'fire_radiative_power', 'confidence']
            },
            'VIIRS': {
                'resolution': 375,  # meters
                'temporal_resolution': 'daily',
                'bands': ['bright_ti4', 'bright_ti5', 'frp', 'confidence']
            }
        }

    def ensure_directories(self):
        """Create necessary directories for data storage."""
        dirs = [
            self.data_dir,
            f"{self.data_dir}/raw",
            f"{self.data_dir}/processed",
            f"{self.data_dir}/geojson",
            f"{self.data_dir}/exports"
        ]
        for dir_path in dirs:
            os.makedirs(dir_path, exist_ok=True)

    def download_firms_data(self,
                            bbox: Tuple[float, float, float, float],
                            start_date: str,
                            end_date: str,
                            source: str = 'MODIS_C6') -> pd.DataFrame:
        """
        Download fire data from NASA FIRMS API.

        Args:
            bbox: Bounding box as (min_lon, min_lat, max_lon, max_lat)
            start_date: Start date in 'YYYY-MM-DD' format
            end_date: End date in 'YYYY-MM-DD' format
            source: Data source ('MODIS_C6', 'VIIRS_SNPP', 'VIIRS_NOAA20')

        Returns:
            DataFrame with fire hotspot data
        """
        if self.map_key == "YOUR_NASA_FIRMS_MAP_KEY":
            print("⚠️  Please set your NASA FIRMS API key in the map_key variable")
            print("   Register at: https://firms.modaps.eosdis.nasa.gov/api/")
            return pd.DataFrame()

        bbox_str = f"{bbox[0]},{bbox[1]},{bbox[2]},{bbox[3]}"

        url = f"{self.firms_base_url}/{self.map_key}/{source}/{bbox_str}/1/{start_date}/{end_date}"

        print(f"🔥 Downloading {source} data from {start_date} to {end_date}...")

        try:
            response = requests.get(url, timeout=30)
            response.raise_for_status()

            # Save raw data
            filename = f"{self.data_dir}/raw/{source}_{start_date}_{end_date}.csv"
            with open(filename, 'w') as f:
                f.write(response.text)

            # Load into DataFrame
            df = pd.read_csv(filename)
            print(f"✅ Downloaded {len(df)} fire hotspots")

            return df

        except requests.exceptions.RequestException as e:
            print(f"❌ Error downloading data: {e}")
            return pd.DataFrame()

    def spatiotemporal_fusion(self,
                              modis_df: pd.DataFrame,
                              viirs_df: pd.DataFrame,
                              spatial_threshold: float = 0.5,
                              temporal_threshold: int = 12) -> pd.DataFrame:
        """
        Perform spatiotemporal fusion of MODIS (1km) and VIIRS (375m) fire products.

        This addresses the manuscript's requirement for detailed data fusion techniques.

        Args:
            modis_df: MODIS fire data
            viirs_df: VIIRS fire data
            spatial_threshold: Spatial matching threshold in km
            temporal_threshold: Temporal matching threshold in hours

        Returns:
            Fused fire dataset with enhanced spatial resolution
        """
        print("🛰️  Performing spatiotemporal data fusion...")

        if modis_df.empty or viirs_df.empty:
            print("⚠️  One or both datasets are empty")
            return pd.concat([modis_df, viirs_df], ignore_index=True)

        # Standardize column names
        modis_df = self._standardize_columns(modis_df, 'MODIS')
        viirs_df = self._standardize_columns(viirs_df, 'VIIRS')

        # Convert to datetime
        modis_df['datetime'] = pd.to_datetime(modis_df['acq_date'] + ' ' + modis_df['acq_time'])
        viirs_df['datetime'] = pd.to_datetime(viirs_df['acq_date'] + ' ' + viirs_df['acq_time'])

        fused_data = []

        for _, viirs_point in viirs_df.iterrows():
            # Find spatially and temporally close MODIS points
            spatial_mask = (
                    np.sqrt((modis_df['longitude'] - viirs_point['longitude']) ** 2 +
                            (modis_df['latitude'] - viirs_point['latitude']) ** 2) * 111 < spatial_threshold
            )

            temporal_mask = (
                    abs((modis_df['datetime'] - viirs_point['datetime']).dt.total_seconds()) < temporal_threshold * 3600
            )

            matching_modis = modis_df[spatial_mask & temporal_mask]

            if len(matching_modis) > 0:
                # Use VIIRS higher resolution data as primary, enhance with MODIS
                fused_point = viirs_point.copy()
                fused_point['source'] = 'VIIRS_MODIS_FUSED'
                fused_point['confidence_enhanced'] = max(
                    viirs_point['confidence'],
                    matching_modis['confidence'].max()
                )
                fused_point['frp_enhanced'] = np.mean([
                    viirs_point['frp'],
                    matching_modis['frp'].mean()
                ])
            else:
                # Keep original VIIRS point
                fused_point = viirs_point.copy()
                fused_point['source'] = 'VIIRS_ONLY'
                fused_point['confidence_enhanced'] = viirs_point['confidence']
                fused_point['frp_enhanced'] = viirs_point['frp']

            fused_data.append(fused_point)

        # Add MODIS-only points
        for _, modis_point in modis_df.iterrows():
            spatial_mask = (
                    np.sqrt((viirs_df['longitude'] - modis_point['longitude']) ** 2 +
                            (viirs_df['latitude'] - modis_point['latitude']) ** 2) * 111 < spatial_threshold
            )
            temporal_mask = (
                    abs((viirs_df['datetime'] - modis_point['datetime']).dt.total_seconds()) < temporal_threshold * 3600
            )

            if not any(spatial_mask & temporal_mask):
                modis_point['source'] = 'MODIS_ONLY'
                modis_point['confidence_enhanced'] = modis_point['confidence']
                modis_point['frp_enhanced'] = modis_point['frp']
                fused_data.append(modis_point)

        fused_df = pd.DataFrame(fused_data)
        print(f"✅ Fusion complete: {len(fused_df)} fused fire points")

        return fused_df

    def _standardize_columns(self, df: pd.DataFrame, source: str) -> pd.DataFrame:
        """Standardize column names across different satellite sources."""
        if source == 'MODIS':
            column_mapping = {
                'lat': 'latitude',
                'lon': 'longitude',
                'brightness': 'brightness',
                'scan': 'scan_angle',
                'track': 'track_angle',
                'acq_date': 'acq_date',
                'acq_time': 'acq_time',
                'satellite': 'satellite',
                'confidence': 'confidence',
                'version': 'version',
                'bright_t31': 'brightness_t31',
                'frp': 'frp'
            }
        else:  # VIIRS
            column_mapping = {
                'lat': 'latitude',
                'lon': 'longitude',
                'bright_ti4': 'brightness',
                'scan': 'scan_angle',
                'track': 'track_angle',
                'acq_date': 'acq_date',
                'acq_time': 'acq_time',
                'satellite': 'satellite',
                'confidence': 'confidence',
                'version': 'version',
                'bright_ti5': 'brightness_t5',
                'frp': 'frp'
            }

        # Rename columns that exist
        existing_columns = {k: v for k, v in column_mapping.items() if k in df.columns}
        return df.rename(columns=existing_columns)

    def extract_features(self, fire_df: pd.DataFrame) -> Dict[str, float]:
        """
        Extract comprehensive fire features for decision-making models.

        Features include:
        - Fire frequency metrics
        - Fire Radiative Power (FRP) statistics
        - Temporal patterns
        - Initial opinion values for consensus models

        Args:
            fire_df: Fire hotspot data

        Returns:
            Dictionary of extracted features
        """
        if fire_df.empty:
            return self._empty_features()

        features = {}

        # Basic fire metrics
        features['total_fire_count'] = len(fire_df)
        features['fire_density'] = len(fire_df) / self._calculate_area(fire_df)

        # FRP statistics
        if 'frp' in fire_df.columns:
            features['mean_frp'] = fire_df['frp'].mean()
            features['max_frp'] = fire_df['frp'].max()
            features['total_frp'] = fire_df['frp'].sum()
            features['frp_std'] = fire_df['frp'].std()

        # Confidence statistics
        if 'confidence' in fire_df.columns:
            features['mean_confidence'] = fire_df['confidence'].mean()
            features['high_confidence_ratio'] = (fire_df['confidence'] >= 80).mean()

        # Temporal patterns
        if 'acq_date' in fire_df.columns:
            fire_df['date'] = pd.to_datetime(fire_df['acq_date'])
            features['fire_duration_days'] = (fire_df['date'].max() - fire_df['date'].min()).days + 1
            features['daily_fire_rate'] = features['total_fire_count'] / features['fire_duration_days']

            # Weekly pattern
            fire_df['weekday'] = fire_df['date'].dt.dayofweek
            features['weekend_fire_ratio'] = (fire_df['weekday'] >= 5).mean()

        # Spatial clustering
        features['spatial_dispersion'] = self._calculate_spatial_dispersion(fire_df)

        # Initial opinion values for consensus decision-making
        # Based on fire risk assessment (0-1 scale)
        risk_score = min(1.0, (
                0.3 * min(1.0, features['fire_density'] / 10) +
                0.3 * min(1.0, features.get('mean_frp', 0) / 100) +
                0.2 * features.get('high_confidence_ratio', 0.5) +
                0.2 * min(1.0, features['daily_fire_rate'] / 5)
        ))

        features['initial_opinion_risk'] = risk_score
        features['initial_opinion_urgency'] = min(1.0, risk_score * 1.2)
        features['initial_opinion_resources'] = min(1.0, risk_score * 0.8)

        print(f"✅ Extracted {len(features)} features")
        return features

    def _empty_features(self) -> Dict[str, float]:
        """Return empty feature set with default values."""
        return {
            'total_fire_count': 0,
            'fire_density': 0,
            'mean_frp': 0,
            'max_frp': 0,
            'total_frp': 0,
            'frp_std': 0,
            'mean_confidence': 0,
            'high_confidence_ratio': 0,
            'fire_duration_days': 0,
            'daily_fire_rate': 0,
            'weekend_fire_ratio': 0,
            'spatial_dispersion': 0,
            'initial_opinion_risk': 0,
            'initial_opinion_urgency': 0,
            'initial_opinion_resources': 0
        }

    def _calculate_area(self, fire_df: pd.DataFrame) -> float:
        """Calculate approximate area covered by fire points in km²."""
        if len(fire_df) < 2:
            return 1.0

        lat_range = fire_df['latitude'].max() - fire_df['latitude'].min()
        lon_range = fire_df['longitude'].max() - fire_df['longitude'].min()

        # Approximate area calculation
        area = lat_range * lon_range * 111 * 111  # km²
        return max(1.0, area)

    def _calculate_spatial_dispersion(self, fire_df: pd.DataFrame) -> float:
        """Calculate spatial dispersion of fire points."""
        if len(fire_df) < 2:
            return 0.0

        center_lat = fire_df['latitude'].mean()
        center_lon = fire_df['longitude'].mean()

        distances = np.sqrt(
            (fire_df['latitude'] - center_lat) ** 2 +
            (fire_df['longitude'] - center_lon) ** 2
        )

        return distances.std()

    def aggregate_to_cities(self,
                            fire_df: pd.DataFrame,
                            city_boundaries: gpd.GeoDataFrame) -> pd.DataFrame:
        """
        Aggregate fire data to city-level using spatial polygons.

        Args:
            fire_df: Fire hotspot data
            city_boundaries: GeoDataFrame with city boundaries

        Returns:
            City-level aggregated fire data
        """
        print("📍 Aggregating fire data to city level...")

        if fire_df.empty:
            return pd.DataFrame()

        # Convert fire data to GeoDataFrame
        fire_gdf = gpd.GeoDataFrame(
            fire_df,
            geometry=gpd.points_from_xy(fire_df['longitude'], fire_df['latitude']),
            crs='EPSG:4326'
        )

        # Ensure same CRS
        if city_boundaries.crs != fire_gdf.crs:
            city_boundaries = city_boundaries.to_crs(fire_gdf.crs)

        city_fire_data = []

        for _, city in city_boundaries.iterrows():
            # Find fires within city boundary
            city_fires = fire_gdf[fire_gdf.geometry.within(city.geometry)]

            if len(city_fires) > 0:
                # Extract features for this city
                features = self.extract_features(city_fires)

                # Add city information
                features['city_name'] = city.get('name', f'City_{city.name}')
                features['city_id'] = city.name
                features['geometry'] = city.geometry

                city_fire_data.append(features)
            else:
                # City with no fires - add empty record
                features = self._empty_features()
                features['city_name'] = city.get('name', f'City_{city.name}')
                features['city_id'] = city.name
                features['geometry'] = city.geometry
                city_fire_data.append(features)

        result_df = pd.DataFrame(city_fire_data)
        print(f"✅ Aggregated data for {len(result_df)} cities")

        return result_df

    def generate_city_geojson(self,
                              city_names: List[str],
                              country: str = 'China') -> gpd.GeoDataFrame:
        """
        Generate GeoJSON boundaries for specified cities.

        Args:
            city_names: List of city names
            country: Country name for context

        Returns:
            GeoDataFrame with city boundaries
        """
        print(f"🌐 Generating GeoJSON for {len(city_names)} cities...")

        # This is a simplified implementation
        # In practice, you would use APIs like OpenStreetMap Nominatim or Google Maps

        geometries = []
        for i, city in enumerate(city_names):
            # Create sample bounding boxes (replace with actual geocoding)
            lat_base = 35.0 + i * 2.0  # Sample coordinates
            lon_base = 110.0 + i * 2.0

            # Create a sample polygon (square)
            from shapely.geometry import Polygon
            polygon = Polygon([
                (lon_base, lat_base),
                (lon_base + 1, lat_base),
                (lon_base + 1, lat_base + 1),
                (lon_base, lat_base + 1),
                (lon_base, lat_base)
            ])

            geometries.append({
                'name': city,
                'country': country,
                'geometry': polygon
            })

        gdf = gpd.GeoDataFrame(geometries, crs='EPSG:4326')

        # Save to file
        output_file = f"{self.data_dir}/geojson/cities_{country.lower()}.geojson"
        gdf.to_file(output_file, driver='GeoJSON')
        print(f"✅ Saved city boundaries to {output_file}")

        return gdf

    def export_modeling_data(self,
                             city_data: pd.DataFrame,
                             format: str = 'excel',
                             filename: Optional[str] = None) -> str:
        """
        Export processed data in modeling-ready formats.

        Args:
            city_data: Processed city-level fire data
            format: Export format ('excel', 'csv', 'json')
            filename: Optional custom filename

        Returns:
            Path to exported file
        """
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"fire_modeling_data_{timestamp}"

        output_path = f"{self.data_dir}/exports/{filename}"

        # Remove geometry column for non-GIS formats
        export_data = city_data.copy()
        if 'geometry' in export_data.columns:
            export_data = export_data.drop('geometry', axis=1)

        if format.lower() == 'excel':
            output_path += '.xlsx'
            with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                export_data.to_excel(writer, sheet_name='Fire_Data', index=False)

                # Add metadata sheet
                metadata = pd.DataFrame({
                    'Parameter': ['Export_Date', 'Total_Cities', 'Data_Sources', 'Spatial_Resolution'],
                    'Value': [
                        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        len(export_data),
                        'MODIS_C6, VIIRS_SNPP, VIIRS_NOAA20',
                        '375m (VIIRS) / 1km (MODIS)'
                    ]
                })
                metadata.to_excel(writer, sheet_name='Metadata', index=False)

        elif format.lower() == 'csv':
            output_path += '.csv'
            export_data.to_csv(output_path, index=False)

        elif format.lower() == 'json':
            output_path += '.json'
            export_data.to_json(output_path, orient='records', indent=2)

        print(f"✅ Exported data to {output_path}")
        return output_path


# Google Earth Engine Integration
class GEEFireVisualizer:
    """Google Earth Engine integration for fire data visualization and analysis."""

    def __init__(self):
        if not EE_AVAILABLE:
            print("⚠️  Google Earth Engine not available")
            return

        try:
            ee.Initialize()
            self.initialized = True
            print("✅ Google Earth Engine initialized")
        except Exception as e:
            print(f"❌ Failed to initialize Google Earth Engine: {e}")
            print("   Please authenticate with: earthengine authenticate")
            self.initialized = False

    def create_fire_heatmap(self,
                            bbox: Tuple[float, float, float, float],
                            start_date: str,
                            end_date: str) -> Optional[str]:
        """
        Create fire heatmap using Google Earth Engine.

        Args:
            bbox: Bounding box as (min_lon, min_lat, max_lon, max_lat)
            start_date: Start date in 'YYYY-MM-DD' format
            end_date: End date in 'YYYY-MM-DD' format

        Returns:
            URL to the generated heatmap
        """
        if not self.initialized:
            return None

        # Define area of interest
        aoi = ee.Geometry.Rectangle([bbox[0], bbox[1], bbox[2], bbox[3]])

        # Load MODIS fire data
        modis_fire = ee.ImageCollection('MODIS/006/MOD14A1') \
            .filterDate(start_date, end_date) \
            .filterBounds(aoi) \
            .select('FireMask')

        # Load VIIRS fire data
        viirs_fire = ee.ImageCollection('MODIS/006/VNP14IMGML') \
            .filterDate(start_date, end_date) \
            .filterBounds(aoi)

        # Create fire density map
        fire_count = modis_fire.select('FireMask').sum()

        # Visualization parameters
        vis_params = {
            'min': 0,
            'max': 10,
            'palette': ['blue', 'cyan', 'yellow', 'orange', 'red']
        }

        # Generate map URL
        map_url = fire_count.getMapId(vis_params)['tile_fetcher'].url_format

        print(f"🗺️  Fire heatmap generated: {map_url}")
        return map_url


# Example usage and testing
def main():
    """Main function demonstrating the FireDataToolkit usage."""

    print("🔥 FireDataToolkit - Urban Fire Remote Sensing Data Processor")
    print("=" * 60)

    # Initialize processor
    processor = FireDataProcessor()

    # Example: Chinese cities
    chinese_cities = [
        'Beijing', 'Shanghai', 'Guangzhou', 'Shenzhen', 'Chengdu',
        'Hangzhou', 'Wuhan', 'Xi\'an', 'Nanjing', 'Tianjin'
    ]

    # Generate city boundaries (replace with actual geocoding)
    city_boundaries = processor.generate_city_geojson(chinese_cities, 'China')

    # Example bounding box for China
    china_bbox = (73.0, 18.0, 135.0, 54.0)  # (min_lon, min_lat, max_lon, max_lat)

    # Date range
    start_date = '2024-01-01'
    end_date = '2024-01-31'

    # Download fire data
    print("\n1. Downloading fire data...")
    modis_data = processor.download_firms_data(china_bbox, start_date, end_date, 'MODIS_C6')
    viirs_data = processor.download_firms_data(china_bbox, start_date, end_date, 'VIIRS_SNPP')

    # Perform spatiotemporal fusion
    print("\n2. Performing spatiotemporal fusion...")
    fused_data = processor.spatiotemporal_fusion(modis_data, viirs_data)

    # Aggregate to city level
    print("\n3. Aggregating to city level...")
    city_fire_data = processor.aggregate_to_cities(fused_data, city_boundaries)

    # Export results
    print("\n4. Exporting results...")
    excel_file = processor.export_modeling_data(city_fire_data, 'excel')
    csv_file = processor.export_modeling_data(city_fire_data, 'csv')

    # Generate visualization (if GEE is available)
    print("\n5. Generating visualization...")
    visualizer = GEEFireVisualizer()
    if visualizer.initialized:
        heatmap_url = visualizer.create_fire_heatmap(china_bbox, start_date, end_date)

    print("\n✅ Processing complete!")
    print(f"📊 Processed data for {len(city_fire_data)} cities")
    print(f"📁 Files saved in: {processor.data_dir}")

    return processor, city_fire_data


if __name__ == "__main__":
    processor, data = main()