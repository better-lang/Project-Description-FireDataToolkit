
import geopandas as gpd
import pandas as pd
from shapely.geometry import Point

def preprocess_fire_data(fire_csv):
    df = pd.read_csv(fire_csv)
    df['geometry'] = df.apply(lambda row: Point(row['longitude'], row['latitude']), axis=1)
    gdf = gpd.GeoDataFrame(df, geometry='geometry')
    return gdf

def aggregate_by_city(gdf, city_shapefile):
    cities = gpd.read_file(city_shapefile)
    joined = gpd.sjoin(gdf, cities, how='inner', predicate='intersects')
    result = joined.groupby('NAME')['frp'].agg(['count', 'mean']).reset_index()
    result.columns = ['City', 'Fire_Count', 'Avg_FRP']
    return result

# Example usage
# gdf_fire = preprocess_fire_data("./fire_data/FIRMS_MODIS_China_2024-04-01_2024-04-30.csv")
# summary = aggregate_by_city(gdf_fire, "./china_city_shapefile.shp")
# summary.to_excel("china_fire_summary.xlsx", index=False)
