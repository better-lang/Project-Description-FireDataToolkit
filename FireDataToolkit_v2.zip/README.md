
# FireDataToolkit 🔥

A modular Python toolkit for downloading, preprocessing, and formatting global urban fire remote sensing data, specifically supporting the construction of Digital Twin-based fire consensus models such as HOD-CC-CRP.

---

## 🌍 Data Sources and Coverage

| Source        | Product                   | Spatial Res. | Temporal Res. | Global Coverage | Use Case                          |
|---------------|---------------------------|---------------|----------------|------------------|-----------------------------------|
| NASA FIRMS    | MODIS, VIIRS              | 1km / 375m    | 1–4 times/day  | Yes              | Daily fire detection, FRP         |
| Sentinel-3    | SLSTR Active Fire         | 500m          | Twice/day      | Yes              | Hotspot confirmation              |
| Google Earth Engine | FIRMS, MODIS, etc.  | 375m–1km      | Customizable   | Yes              | Heatmap visualization, AI model   |
| Landsat-8/9   | Surface Reflectance       | 30m           | 16 days        | Yes              | Burn scar / vegetation extraction |
| Sentinel-2    | MSI                       | 10–20m        | 5 days         | Yes              | Post-fire assessment              |

---

## 🛠 Modules Overview

### `fire_data_downloader.py`
- Downloads daily MODIS/VIIRS fire point data by country.
- Input: Country name, date range.
- Output: Raw CSV fire point records including latitude, longitude, FRP, acquisition time, confidence.

### `fire_data_formatter.py`
- Converts fire point records into city-level summaries.
- Aggregates by shapefile or GeoDataFrame (e.g., by administrative city boundaries).
- Outputs:
  - Fire frequency (`Fire_Count`)
  - Average Fire Radiative Power (`Avg_FRP`)
  - Initial opinion value (`o_k`) for modeling

### `gee_export_template.py`
- Template for exporting fire heatmaps or images from Google Earth Engine.
- Requires Earth Engine authentication.
- Region selection via rectangle coordinates.

### `generate_city_geojson.py`
- For each city in a climate zone list, generate a buffered rectangular GEE-compatible GeoJSON region.
- Input: Latitude, Longitude
- Output: Region_GeoJSON column with polygon definitions

---

## 📈 Preprocessing Pipeline

1. **Data Collection**
   - Download MODIS/VIIRS fire points via FIRMS API.
   - Optionally collect Sentinel-2/3 and Landsat imagery via GEE or Copernicus Open Hub.

2. **Data Fusion**
   - MODIS (1km) and VIIRS (375m) fire points are merged using time and location proximity.
   - Sentinel-3 SLSTR used to confirm or complement active fire areas.

3. **Feature Extraction**
   - Extract fire intensity (FRP), time, and confidence level.
   - Optionally derive NDVI/NBR indices using Sentinel-2 or Landsat (for burn severity).
   - Compute `log10(fire_count) / max_log` as opinion value for modeling input.

4. **Geo-Mapping**
   - Join fire points to city polygons using spatial joins (`geopandas.sjoin`).
   - Optionally aggregate by grid or administrative level.

5. **Export for Modeling**
   - Generate Excel/CSV ready for consensus modeling:
     - `formatted_opinions.xlsx`
     - `formatted_decision_matrix_E.xlsx`

---

## 🔗 Reproducibility

- All scripts are open-source and provided in this repository.
- Sample dataset structure and API references included.
- Easily extendable to support other regions, time periods, or sensor sources.

## 📦 How to Use

```bash
pip install -r requirements.txt
python fire_data_downloader.py
python fire_data_formatter.py
python generate_city_geojson.py
```

---

## 📤 Upload to GitHub

You can create a new GitHub repository and push this project using:

```bash
git init
git remote add origin https://github.com/your-username/fire-data-toolkit.git
git add .
git commit -m "Initial commit with fire data preprocessing toolkit"
git push -u origin master
```

---

## 🧠 Citation & Acknowledgment

Please cite NASA FIRMS, ESA Copernicus, Google Earth Engine, and this toolkit if used in academic research.

---
