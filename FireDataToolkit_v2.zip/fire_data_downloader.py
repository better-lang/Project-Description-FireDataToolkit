
import requests
import pandas as pd
import os
from datetime import datetime
import geopandas as gpd
from shapely.geometry import Point

FIRMS_API_KEY = "your_firms_api_key_here"
FIRMS_PRODUCTS = {
    "MODIS": "MODIS_C6_1_Global_24h",
    "VIIRS": "VIIRS_SNPP_NRT_Global_24h"
}
COUNTRIES = ["China", "Brazil", "USA", "Indonesia"]
START_DATE = "2024-04-01"
END_DATE = "2024-04-30"
OUTPUT_DIR = "./fire_data/"

os.makedirs(OUTPUT_DIR, exist_ok=True)

def download_firms_data(product, country, api_key, start, end):
    url = f"https://firms.modaps.eosdis.nasa.gov/api/country/csv/{api_key}/{product}/{country}/1/{start}/{end}"
    response = requests.get(url)
    filename = f"{OUTPUT_DIR}FIRMS_{product}_{country}_{start}_{end}.csv"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(response.text)
    print(f"[✓] Saved: {filename}")
    return filename

for country in COUNTRIES:
    for product in FIRMS_PRODUCTS.values():
        download_firms_data(product, country, FIRMS_API_KEY, START_DATE, END_DATE)
