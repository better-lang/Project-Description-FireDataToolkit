
import pandas as pd
import json

def create_rectangle_geojson(lat, lon, buffer_deg=0.3):
    return [
        [lon - buffer_deg, lat - buffer_deg],
        [lon + buffer_deg, lat - buffer_deg],
        [lon + buffer_deg, lat + buffer_deg],
        [lon - buffer_deg, lat + buffer_deg],
        [lon - buffer_deg, lat - buffer_deg]
    ]

def process_excel(input_file, output_file, buffer_deg=0.3):
    df = pd.read_excel(input_file)

    if not {'Latitude', 'Longitude'}.issubset(df.columns):
        raise ValueError("输入文件必须包含 Latitude 和 Longitude 列")

    geojsons = []
    for _, row in df.iterrows():
        lat = row['Latitude']
        lon = row['Longitude']
        polygon = create_rectangle_geojson(lat, lon, buffer_deg)
        geojson_str = json.dumps(polygon)
        geojsons.append(geojson_str)

    df['Region_GeoJSON'] = geojsons
    df.to_excel(output_file, index=False)
    print(f"[✓] 成功生成带有 GEE 区域的城市文件：{output_file}")

if __name__ == "__main__":
    INPUT_FILE = "global_city_climate_zones.xlsx"
    OUTPUT_FILE = "global_city_with_geojson.xlsx"
    BUFFER_DEGREE = 0.3

    process_excel(INPUT_FILE, OUTPUT_FILE, BUFFER_DEGREE)
